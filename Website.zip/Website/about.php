<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
   <?php include 'menu.php'?>

<div class="jumbotron">
  <h1>Unnati Varshney</h1>
  <p>We don’t inherit the earth from our ancestors, we borrow it from our children</p>
</div>
<section class="my-5">
  <div class="py-5">

    <h2 class="text-center">About Us</h2>
  </div>
  <div class="container-fluid">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-12">
      <img src="images/images3.jpg" class="img-fluid aboutimg">
    </div>
    <div class="col-lg-6 col-md-6 col-12">
      <h2 class="display-4">I AM UNNATI VARSHNEY</h2>
      <p class="py-3">Web programming, also known as web development, is the creation of dynamic web applications. Examples of web applications are social networking sites like Facebook or e-commerce sites like Amazon. The good news is that learning web development is not that hard!</p>
      <a href="about.php" class="btn btn-success"> Wannna Know Me</a>
    </div>
  </div>
</div>
</section>
<footer>
  
  <p class="p-3 bg-dark text-white text-center">@unnativarshney</p>
</footer>