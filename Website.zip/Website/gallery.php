<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
   <?php include 'menu.php'?>

<section class="my-5">
	<div class="py-5">
		<h2 class="text-center"> Our Gallery</h2>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>
		<div class="col-lg-4 col-md-4 col-12">
				<img src="images/images3.jpg" class="img-fluid pb-3"  width="500" height="600">
		</div>

	</div>
	</section>
	