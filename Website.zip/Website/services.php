<!DOCYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
</head>
<body>
   <?php include 'menu.php'?>

<div class="jumbotron">
  <h1>Unnati Varshney</h1>
  <p>We don’t inherit the earth from our ancestors, we borrow it from our children</p>
</div>
<section class="my-5">
	<div class="py-5">
		<h2 class="text-center"> Our Services</h2>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/images4.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Beautiful Nature</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/images4.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Beautiful Nature</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<div class="card">
  <img class="card-img-top" src="images/images4.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Beautiful Nature</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
			</div>
		</div>
	</div>
	<footer>
	
	<p class="p-3 bg-dark text-white text-center">@unnativarshney</p>
</footer>
</section>
</body>
</html>